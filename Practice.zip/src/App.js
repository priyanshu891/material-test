import "./App.css";
import Carousel from "./Carousel";

function App() {
  return (
    <div className="container mt-5">
      <Carousel />
    </div>
  );
}

export default App;
